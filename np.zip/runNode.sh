#bin/bash

DBUSER=postgres DBPASS=100101 DBHOST=localhost DBNAME=testdb1 npm start
